# Threshold Miku Skin for Steam
From [Threshold Skin](https://github.com/Edgarware/Threshold-Skin)  
Modified By JackMyth  


![](Previews/Main.jpg)

## Installation
1. Download the skin, extract the zip file, and copy the folder to:
   * Windows - C:\Program Files (x86)\Steam\skins
   * Mac - /Users/\<username\>/Library/Application Support/Steam/Steam.AppBundle/Steam/Contents/MacOS/skins/
   * Linux - ~/.steam/skins

2. In Steam, go to Settings > Interface > and choose Threshold Miku from the list of skins.

3. Restart Steam and enjoy!
